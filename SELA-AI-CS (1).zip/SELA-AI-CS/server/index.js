import { File } from "node:buffer";
if (!globalThis.File) globalThis.File = File;

import express from "express";
import cors from "cors";
import multer from "multer";
import Groq, { toFile } from "groq-sdk";
import { config } from "dotenv";
import { fileURLToPath } from "url";
import { dirname, join } from "path";

const __dirname = dirname(fileURLToPath(import.meta.url));
config({ path: join(__dirname, "..", ".env.local") });

const app = express();
const upload = multer({ storage: multer.memoryStorage() });

app.use(cors());
app.use(express.json());

const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });
const CHAT_MODEL =
  process.env.GROQ_CHAT_MODEL || process.env.GROQ_MODEL || "openai/gpt-oss-120b";
const TRANSCRIPTION_MODEL = process.env.GROQ_TRANSCRIPTION_MODEL || "whisper-large-v3";

// ── Intent Detection ──────────────────────────────────────────────────────────
const SMALL_TALK_PATTERNS = [
  "halo", "hai", " hi ", "hello", "hey", "siapa kamu", "kamu siapa",
  "nama kamu", "kamu apa", "apa itu sela", "apa kabar", "gimana kabar",
  "baik-baik", "selamat pagi", "selamat siang", "selamat sore", "selamat malam",
  "good morning", "good afternoon", "good evening", "good night", "how are you",
  "who are you", "what are you", "introduce yourself", "perkenalkan", "kenalkan",
];

const CAMPUS_PATTERNS = [
  "ucic", "universitas", "kampus", "mahasiswa", "mahasiswi", "fakultas",
  "jurusan", "prodi", "program studi", "pendaftaran", "pmb", "daftar kuliah",
  "kuliah di", "wisuda", "akademik", "dosen", "semester", "sks", "ipk",
  "beasiswa", "krs", "khs", "ospek", "orientasi", "catur insan", "cirebon",
];

function detectIntent(query) {
  const q = " " + query.toLowerCase().trim() + " ";
  if (q.trim().length < 3) return "unclear";
  if (SMALL_TALK_PATTERNS.some((p) => q.includes(p))) return "small_talk";
  if (CAMPUS_PATTERNS.some((p) => q.includes(p))) return "campus";
  return "general";
}

// ── POST /api/transcribe ──────────────────────────────────────────────────────
app.post("/api/transcribe", upload.single("file"), async (req, res) => {
  try {
    if (!process.env.GROQ_API_KEY) {
      return res.status(500).json({
        error: "Konfigurasi server belum lengkap.",
        detail: "GROQ_API_KEY belum diisi di .env.local",
      });
    }

    console.log(
      "[transcribe] req.file:",
      req.file
        ? `name=${req.file.originalname} size=${req.file.size}`
        : "UNDEFINED",
    );
    if (!req.file) return res.status(400).json({ error: "No file uploaded" });
    const lang = req.body.lang || "id";
    const buffer = req.file.buffer;
    const fileName = req.file.originalname || "audio.webm";

    const file = await toFile(buffer, fileName, {
      type: req.file.mimetype || "audio/webm",
    });

    const promptID =
      "SELA, UCIC, Universitas Catur Insan Cendekia, Cirebon, kampus, mahasiswa, akademik, fakultas, pendaftaran, beasiswa, wisuda, oke, ya, tidak, gimana, kenapa, kapan, di mana, berapa, siapa, tolong, bisa, mau, ingin, bagaimana, apakah, dong, sih, nih, loh, deh, emang, memang, banget";
    const promptEN =
      "SELA, UCIC, Universitas Catur Insan Cendekia, Cirebon, campus, student, academic, faculty, registration, scholarship, graduation, okay, yes, no, how, why, when, where, how much, who, please, can, want, would like, really, actually";

    console.log(`[transcribe] Calling Groq Whisper API with lang=${lang}...`);
    const transcription = await groq.audio.transcriptions.create({
      file,
      model: TRANSCRIPTION_MODEL,
      language: lang,
      response_format: "json",
      prompt: lang === "en" ? promptEN : promptID,
    });

    const transcribedText = transcription.text || "";
    const isBackgroundAudio = detectBackgroundAudio(transcribedText, lang);

    if (isBackgroundAudio) {
      console.log(
        `[transcribe] ⚠ FILTERED: Background audio detected: "${transcribedText.slice(0, 50)}..."`,
      );
      return res.json({
        text: "",
        reason: "Background audio detected - likely not a real question",
        originalTranscript: transcribedText,
      });
    }

    if (transcribedText.trim().length < 5) {
      console.log(`[transcribe] ⚠ FILTERED: Too short: "${transcribedText}"`);
      return res.json({
        text: "",
        reason: "Transcription too short - likely noise",
      });
    }

    console.log(`[transcribe] Success: "${transcribedText.slice(0, 60)}..."`);
    res.json({ text: transcribedText });
  } catch (err) {
    console.error("[transcribe] Full error:", {
      message: err?.message,
      status: err?.status,
      code: err?.code,
      type: err?.type,
    });
    res.status(500).json({
      error: "Gagal mengenali suara.",
      detail: err?.message,
      status: err?.status,
      hint: "Pastikan API key Groq valid dan aktif",
    });
  }
});

function detectBackgroundAudio(text, lang) {
  if (!text) return false;
  const lower = text.toLowerCase().trim();
  const bgPatterns = [
    /^(terima kasih telah|thanks for|welcome to|selamat datang)/i,
    /^(subscribe|subscrib|subscribe now|like and share)/i,
    /^(don't forget to|jangan lupa)/i,
    /(goodbye|farewell|see you|cepatnya|sampai jumpa)/i,
    /^(♪|music|lagu|nyanyian|instrumental)/i,
    /^(promo|promosi|diskon|special offer|gratis)/i,
  ];

  for (const pattern of bgPatterns) {
    if (pattern.test(lower)) return true;
  }

  const words = lower.split(/\s+/);
  if (words.length <= 2 && lower.length < 15) {
    const shortQuestionPatterns = [
      /^(apa|berapa|siapa|kapan|dimana|gimana|kenapa|bagaimana)/,
      /^(yes|no|ya|tidak)/,
    ];
    const isValidShortQuestion = shortQuestionPatterns.some((p) => p.test(lower));
    if (!isValidShortQuestion) return true;
  }

  return false;
}

// ── POST /api/chat ────────────────────────────────────────────────────────────
app.post("/api/chat", async (req, res) => {
  try {
    if (!process.env.GROQ_API_KEY) {
      return res.status(500).json({
        error: "Konfigurasi server belum lengkap.",
        details: "GROQ_API_KEY belum diisi di .env.local",
      });
    }

    const { messages, userQuery = "", transcriptDebug = null } = req.body;

    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({
        error: "Format request chat tidak valid.",
        details: "Body harus berisi array messages.",
      });
    }

    console.log(`[SELA Chat] Menerima pertanyaan: "${userQuery.slice(0, 50)}"`);
    if (transcriptDebug) {
      console.log("[SELA Chat] Transcript debug:", {
        raw: transcriptDebug.rawUserQuery,
        cleaned: transcriptDebug.cleanedUserQuery,
        marker: transcriptDebug.transcriptMarker,
      });
    }

    const completion = await groq.chat.completions.create({
      messages: messages,
      model: CHAT_MODEL,
      temperature: 0.5,
      max_tokens: 900,
    });

    const choice = completion.choices[0];
    const responseText = choice?.message?.content || "";

    if (choice?.finish_reason === "length") {
      console.warn(
        `[SELA Chat] ⚠ Respons terpotong (finish_reason=length). Panjang: ${responseText.length} karakter. Pertimbangkan menaikkan max_tokens lagi atau memperketat instruksi "SPESIFIK & SINGKAT".`,
      );
    }

    res.json({ text: responseText });
  } catch (err) {
    console.error("Chat error:", {
      message: err?.message,
      status: err?.status,
      code: err?.code,
      type: err?.type,
      model: CHAT_MODEL,
    });
    res.status(502).json({
      error: "Gagal mendapat respons AI.", 
      details: err?.error?.message || err.message,
      model: CHAT_MODEL,
    });
  }
});

const PORT = process.env.SERVER_PORT || 3001;
app.listen(PORT, () => {
  console.log(`SELA backend running on http://localhost:${PORT}`);
});