import React, { Suspense, useEffect, useMemo, useRef } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { useGLTF, useAnimations, Environment, ContactShadows, OrbitControls } from '@react-three/drei'
import * as THREE from 'three'

// Nama tulang lengan (deform bones) di rig SELA_BARU.glb.
// Klip animasi bawaan model ("Idle"/"Talking") ternyata cuma pose statis
// berdurasi 0 detik (1 keyframe), bukan gerakan — jadi kalau cuma
// diputar lewat mixer, tangan akan "loncat" ke satu pose lalu diam lagi.
// Karena itu kita tambahkan goyangan halus tiap frame di atas pose dasar
// supaya karakter terlihat hidup, terutama saat sedang bicara.
// PERBAIKAN: rig SELA_BARU.glb (hasil ekspor rig bertipe Rigify) TIDAK memakai
// scale negatif untuk memirror sisi kiri/kanan — sisi .R dibuat lewat rotasi,
// bukan refleksi. Efeknya, offset fase yang "benar secara mirror" (supaya
// lengan kanan bergerak sebagai bayangan cermin lengan kiri, bukan malah
// melawan arahnya) TERNYATA BERBEDA per tulang, tergantung arah sumbu lokal
// masing-masing tulang terhadap dunia:
//   - upper_arm & hand -> perlu phase +PI di sisi .R (sudah benar di kode lama)
//   - forearm           -> justru perlu phase SAMA PERSIS dengan sisi .L
// Kode lama memberi +PI ke ketiganya secara seragam, sehingga khusus siku
// kanan (forearm.R) bengkok berlawanan arah dari lengan-atas & tangan di sisi
// yang sama -> gerakan lengan kanan terlihat "terpelintir"/terbalik, paling
// kentara di tangan (ujung rantai tulang). Sudah diverifikasi numerik dengan
// membaca bind-pose matrix tiap tulang dari file .glb; residual error mirror
// turun dari ~0.19 menjadi ~0.0001 setelah forearm.R dikembalikan ke phase 0.8.
// PERBAIKAN SIKU: sebelumnya goyangan siku (forearm) memakai sin() murni,
// yang berayun SIMETRIS ke dua arah dari pose dasar (menekuk lebih & kurang
// dari pose dasarnya). Karena pose dasar siku sudah hampir lurus, separuh
// siklus ayunan itu mendorong siku ke arah "kurang dari lurus" alias
// hiperekstensi — gerakan yang mustahil untuk siku manusia sungguhan, jadi
// terlihat seperti patah/terpelintir ke arah yang salah (persis keluhan
// "kebalik" saat bicara). Sekarang goyangan siku dibuat SATU ARAH saja
// (unidirectional: true) lewat (sin(x)+1)/2 -> hasilnya 0..amp, bukan
// -amp..+amp, jadi siku cuma pernah menekuk LEBIH dari pose dasar, tidak
// pernah ke arah sebaliknya. Tulang bahu (upper_arm) & tangan (hand) tetap
// dibiarkan simetris karena sendi itu wajar bergerak dua arah.
const ARM_BONES = [
  { name: 'DEF-upper_arm.L', axis: [0, 0, 1], freq: 0.5, amp: 0.14, phase: 0 },
  { name: 'DEF-forearm.L', axis: [1, 0, 0], freq: 0.8, amp: 0.22, phase: 0.8, unidirectional: true },
  // Frekuensi tangan sedikit lebih rendah dari forearm/upper_arm supaya
  // goyangan di ujung rantai tulang ini terasa halus, bukan "gemetar".
  { name: 'DEF-hand.L', axis: [0, 1, 0], freq: 0.95, amp: 0.22, phase: 1.6 },
  { name: 'DEF-upper_arm.R', axis: [0, 0, 1], freq: 0.5, amp: 0.14, phase: Math.PI },
  { name: 'DEF-forearm.R', axis: [1, 0, 0], freq: 0.8, amp: 0.22, phase: 0.8, unidirectional: true },
  { name: 'DEF-hand.R', axis: [0, 1, 0], freq: 0.95, amp: 0.22, phase: Math.PI + 1.6 },
]

// Tulang tulang belakang & dada untuk simulasi napas. Sama seperti lengan,
// tulang-tulang ini statis (1 keyframe) di semua klip bawaan — jadi badan
// tidak pernah bergerak sama sekali sebelum ini. Berbeda dari lengan (yang
// sengaja dibuat TIDAK sinkron antar tulang supaya terasa organik), semua
// tulang napas di sini SATU FASE yang sama persis (tanpa offset), karena
// dada & perut yang mengembang-mengempis harus terlihat serempak, bukan
// masing-masing bergoyang sendiri-sendiri.
// PERBAIKAN: versi awal cuma memakai ROTASI sumbu X. Sudah dicek matematis
// dari bind-pose matrix tiap tulang (metode sama seperti waktu membenarkan
// arah lengan): sumbu lokal X tulang-tulang ini ternyata SEJAJAR sumbu X
// dunia, dan tulang punggung memanjang ke atas (sumbu Y dunia) — jadi
// rotasi sumbu X membuat dada bergerak MAJU-MUNDUR menjauhi/mendekati
// kamera (sumbu kedalaman/Z), bukan naik-turun atau melebar. Dari kamera
// yang menghadap depan, gerakan maju-mundur seperti itu nyaris tidak
// kelihatan — makanya sebelumnya terlihat seperti tidak bernapas sama
// sekali walau kodenya sudah jalan. Sekarang napas terutama digerakkan
// lewat SKALA (dada "mengembang-mengempis" di sumbu X & Z, bukan rotasi),
// karena perubahan ukuran selalu kelihatan dari sudut kamera manapun —
// beda dari rotasi yang kelihatannya tergantung ke arah mana sumbunya
// menghadap. Rotasi X kecil tetap dipertahankan sebagai sentuhan halus
// tambahan (bukan penggerak utama lagi).
const BREATH_BONES = [
  { name: 'DEF-spine.001', axis: [1, 0, 0], amp: 0.006, scaleAmp: 0.01 },
  { name: 'DEF-spine.002', axis: [1, 0, 0], amp: 0.01, scaleAmp: 0.018 },
  { name: 'DEF-spine.003', axis: [1, 0, 0], amp: 0.014, scaleAmp: 0.03 },
  { name: 'DEF-breast.L', axis: [1, 0, 0], amp: 0.02, scaleAmp: 0.05 },
  { name: 'DEF-breast.R', axis: [1, 0, 0], amp: 0.02, scaleAmp: 0.05 },
]

// Amplitudo & kecepatan goyangan lengan untuk kondisi diam vs bicara. Skala
// kecepatan bicara diturunkan sedikit (2.6 -> 2.2) supaya tulang tangan —
// yang frekuensi dasarnya paling tinggi (0.95) — tidak bergetar terlalu
// cepat/kasar. Nilai ini tidak dipakai mentah-mentah, tapi didekati secara
// bertahap tiap frame lewat damping (lihat SWAY_SMOOTHING) supaya transisi
// idle <-> bicara tidak "meloncat" instan.
const IDLE_SWAY = { amp: 0.5, speed: 1 }
const SPEAKING_SWAY = { amp: 1.3, speed: 2.2 }
// Makin besar nilainya, makin cepat goyangan menyesuaikan ke target barunya;
// ~5 membuat transisi penuh idle<->bicara berlangsung sekitar 0.3-0.5 detik,
// senada dengan durasi crossfade animasi Idle/Talking (0.35s) di bawah,
// supaya keduanya terasa menyatu alih-alih salah satu nyentak duluan.
const SWAY_SMOOTHING = 5

// Napas orang dewasa saat istirahat ~12-16 tarikan/menit (~0.2-0.27 Hz).
// speed di sini dalam rad/s untuk sin(t * speed), jadi 0.2-0.27Hz kira-kira
// speed 1.3-1.7. Saat bicara, napas biasanya sedikit lebih cepat & lebih
// dangkal (napas "terkontrol" untuk bicara) -> amp diturunkan, speed dinaikkan
// sedikit, didekati bertahap dengan damping yang sama seperti goyangan lengan.
const IDLE_BREATH = { amp: 1, speed: 1.6 }
const SPEAKING_BREATH = { amp: 0.6, speed: 2.0 }

// Kedipan mata: jarak antar kedipan acak "beberapa detik sekali", dan durasi
// satu kedipan singkat (mata benar-benar tertutup sekejap lalu terbuka lagi).
const BLINK_INTERVAL_MIN = 2.5
const BLINK_INTERVAL_MAX = 6
const BLINK_DURATION = 0.14

// Gerakan mulut (lipsync) saat bicara. Kita tidak punya akses ke data audio
// mentah dari TTS browser (Web Speech API tidak membocorkan gelombang suara
// ke JS), jadi bentuk mulut digilir bergantian antar morph target viseme
// ("aa"/"ih"/"u"/"e"/"o") mengikuti waktu — bukan disinkronkan presisi per
// fonem, tapi cukup untuk kesan "sedang mengucapkan sesuatu" yang meyakinkan.
// VISEME_CYCLE_SPEED = jumlah pergantian bentuk mulut per detik.
const VISEME_CYCLE = ['aa', 'ih', 'u', 'e', 'o']
const VISEME_CYCLE_SPEED = 7.5
const VISEME_TARGET_WEIGHT = 0.85
// Kecepatan damping transisi antar bentuk mulut — dibuat cukup cepat (beda
// dari SWAY_SMOOTHING yang untuk gerakan badan) supaya mulut terasa "membuka-
// menutup" dengan tegas, bukan lembek/blur seperti goyangan badan.
const VISEME_DAMP_SPEED = 22

function SelaModel({ isSpeaking }) {
  const group = useRef()
  const { scene, animations } = useGLTF('/models/SELA_BARU.glb')

  // PERBAIKAN PENTING: klip "Idle"/"Talking" bawaan file .glb ternyata ikut
  // berisi keyframe untuk tulang lengan & tulang napas yang sama-sama kita
  // gerakkan manual di bawah. Karena AnimationMixer (dari useAnimations) dan
  // kode gerakan kita ini sama-sama menulis ke bone.quaternion tiap frame,
  // siapa pun yang jalan TERAKHIR di frame itu yang menang — dan ternyata
  // mixer-nya yang menang, jadi gerakan kita selalu tertimpa balik sebelum
  // sempat dirender. Supaya tidak lagi rebutan, track quaternion tulang-tulang
  // ini kita buang dari klip SEBELUM dipakai mixer, supaya cuma kode kita
  // yang mengendalikan tulang tersebut. Tulang lain (kepala, wajah, dst)
  // tetap mengikuti animasi Idle/Talking seperti biasa.
  const filteredAnimations = useMemo(() => {
    const controlledBoneNames = new Set([
      ...ARM_BONES.map((b) => b.name),
      ...BREATH_BONES.map((b) => b.name),
    ])
    return animations.map((clip) => {
      const clone = clip.clone()
      clone.tracks = clone.tracks.filter((track) => {
        const boneName = track.name.split('.').slice(0, -1).join('.')
        return !controlledBoneNames.has(boneName)
      })
      return clone
    })
  }, [animations])

  const { actions } = useAnimations(filteredAnimations, group)

  // Crossfade antara pose "Idle" dan pose "Talking" yang sudah ada di file GLB.
  useEffect(() => {
    const idle = actions['Idle']
    const talking = actions['Talking']
    if (!idle || !talking) return

    idle.play()
    talking.play()

    if (isSpeaking) {
      talking.reset().fadeIn(0.35).play()
      idle.fadeOut(0.35)
    } else {
      idle.reset().fadeIn(0.35).play()
      talking.fadeOut(0.35)
    }
  }, [isSpeaking, actions])

  // Simpan referensi + pose dasar (bind pose asli file) tiap tulang yang kita
  // kendalikan manual (lengan + napas). Karena track-nya sudah dibuang dari
  // mixer di atas, tulang-tulang ini TIDAK akan pernah disentuh animasi lagi
  // — baseQuat & baseScale di sini aman dipakai sebagai acuan tetap tiap frame.
  const bonesRef = useRef([])
  useEffect(() => {
    const swayBones = ARM_BONES.map((cfg) => ({ ...cfg, kind: 'sway' }))
    const breathBones = BREATH_BONES.map((cfg) => ({ ...cfg, kind: 'breath' }))
    bonesRef.current = [...swayBones, ...breathBones]
      .map((cfg) => {
        const bone = scene.getObjectByName(cfg.name)
        if (!bone) return null
        return {
          ...cfg,
          bone,
          baseQuat: bone.quaternion.clone(),
          baseScale: bone.scale.clone(),
          axisVec: new THREE.Vector3(...cfg.axis),
        }
      })
      .filter(Boolean)
  }, [scene])

  // Kumpulkan semua mesh yang punya morph target wajah yang kita pakai:
  // kedipan mata ("EyeBlinkLeft"/"EyeBlinkRight") dan bentuk mulut/viseme
  // ("aa"/"ih"/"u"/"e"/"o") — model ini sudah punya morph target tersebut,
  // cuma belum pernah dipakai sama sekali sebelumnya.
  const faceTargets = useMemo(() => {
    const targets = []
    scene.traverse((obj) => {
      const dict = obj.morphTargetDictionary
      if (!dict || !obj.morphTargetInfluences) return
      const leftIndex = dict['EyeBlinkLeft']
      const rightIndex = dict['EyeBlinkRight']
      const visemeIndices = {}
      for (const key of VISEME_CYCLE) {
        if (dict[key] != null) visemeIndices[key] = dict[key]
      }
      if (leftIndex != null || rightIndex != null || Object.keys(visemeIndices).length > 0) {
        targets.push({ mesh: obj, leftIndex, rightIndex, visemeIndices })
      }
    })
    return targets
  }, [scene])

  // Fase goyangan lengan diakumulasi sendiri tiap frame (bertambah sebesar
  // speed_saat_ini * delta), BUKAN dengan mengalikan total waktu berjalan
  // dengan speed seperti sebelumnya — supaya saat speed berubah (idle <->
  // bicara), gerakannya tetap menyambung mulus tanpa lompatan sudut mendadak.
  const phaseRef = useRef(0)
  const swayRef = useRef({ ...IDLE_SWAY })

  // Fase napas, dengan pola damping yang sama seperti goyangan lengan supaya
  // transisi idle <-> bicara terasa menyatu, bukan nyentak.
  const breathPhaseRef = useRef(0)
  const breathRef = useRef({ ...IDLE_BREATH })

  // Timer kedipan mata: kedip acak tiap beberapa detik, tiap kedip berlangsung
  // singkat (buka -> tutup -> buka).
  const blinkRef = useRef({
    elapsed: 0,
    active: false,
    start: 0,
    nextAt: BLINK_INTERVAL_MIN + Math.random() * (BLINK_INTERVAL_MAX - BLINK_INTERVAL_MIN),
  })

  const tmpQuat = useMemo(() => new THREE.Quaternion(), [])

  useFrame((rootState, delta) => {
    const t = rootState.clock.getElapsedTime()
    // --- Goyangan lengan ---
    const swayTarget = isSpeaking ? SPEAKING_SWAY : IDLE_SWAY
    const sway = swayRef.current
    sway.amp = THREE.MathUtils.damp(sway.amp, swayTarget.amp, SWAY_SMOOTHING, delta)
    sway.speed = THREE.MathUtils.damp(sway.speed, swayTarget.speed, SWAY_SMOOTHING, delta)
    phaseRef.current += sway.speed * delta
    const swayPhase = phaseRef.current

    // --- Napas ---
    const breathTarget = isSpeaking ? SPEAKING_BREATH : IDLE_BREATH
    const breath = breathRef.current
    breath.amp = THREE.MathUtils.damp(breath.amp, breathTarget.amp, SWAY_SMOOTHING, delta)
    breath.speed = THREE.MathUtils.damp(breath.speed, breathTarget.speed, SWAY_SMOOTHING, delta)
    breathPhaseRef.current += breath.speed * delta
    const breathValue = Math.sin(breathPhaseRef.current)

    for (const entry of bonesRef.current) {
      if (entry.kind === 'breath') {
        const angle = breathValue * entry.amp * breath.amp
        tmpQuat.setFromAxisAngle(entry.axisVec, angle)
        entry.bone.quaternion.copy(entry.baseQuat).multiply(tmpQuat)

        // Penggerak utama kesan "napas": skala X & Z tulang dada/punggung
        // membesar sedikit saat "menarik napas" lalu kembali mengecil —
        // efek mengembang-mengempis ini kelihatan dari sudut kamera manapun,
        // beda dari rotasi murni yang bisa "menghadap" ke arah yang nyaris
        // tidak terlihat (lihat catatan di atas BREATH_BONES).
        const scaleFactor = 1 + breathValue * entry.scaleAmp * breath.amp
        entry.bone.scale.set(
          entry.baseScale.x * scaleFactor,
          entry.baseScale.y,
          entry.baseScale.z * scaleFactor
        )
      } else {
        const raw = Math.sin(swayPhase * entry.freq + entry.phase)
        // Siku (unidirectional: true): pakai (raw+1)/2 supaya hasilnya
        // 0..1 (selalu menekuk LEBIH dari pose dasar, tidak pernah ke arah
        // hiperekstensi). Sendi lain tetap simetris seperti biasa (-1..1).
        const wave = entry.unidirectional ? (raw + 1) / 2 : raw
        const angle = wave * entry.amp * sway.amp
        tmpQuat.setFromAxisAngle(entry.axisVec, angle)
        entry.bone.quaternion.copy(entry.baseQuat).multiply(tmpQuat)
      }
    }

    // --- Kedipan mata ---
    const blink = blinkRef.current
    blink.elapsed += delta

    if (!blink.active && blink.elapsed >= blink.nextAt) {
      blink.active = true
      blink.start = blink.elapsed
      blink.nextAt =
        blink.elapsed + BLINK_INTERVAL_MIN + Math.random() * (BLINK_INTERVAL_MAX - BLINK_INTERVAL_MIN)
    }

    let blinkWeight = 0
    if (blink.active) {
      const progress = (blink.elapsed - blink.start) / BLINK_DURATION
      if (progress >= 1) {
        blink.active = false
      } else {
        blinkWeight = Math.sin(progress * Math.PI)
      }
    }

    // --- Gerakan mulut (lipsync) saat bicara ---
    // Bentuk mulut digilir tiap 1/VISEME_CYCLE_SPEED detik selama isSpeaking;
    // begitu berhenti bicara, semua target kembali ke 0 (mulut menutup halus).
    const visemeIndex = Math.floor(t * VISEME_CYCLE_SPEED) % VISEME_CYCLE.length
    const activeViseme = isSpeaking ? VISEME_CYCLE[visemeIndex] : null

    for (const face of faceTargets) {
      if (face.leftIndex != null) face.mesh.morphTargetInfluences[face.leftIndex] = blinkWeight
      if (face.rightIndex != null) face.mesh.morphTargetInfluences[face.rightIndex] = blinkWeight

      for (const key of VISEME_CYCLE) {
        const idx = face.visemeIndices[key]
        if (idx == null) continue
        const target = key === activeViseme ? VISEME_TARGET_WEIGHT : 0
        const current = face.mesh.morphTargetInfluences[idx] || 0
        face.mesh.morphTargetInfluences[idx] = THREE.MathUtils.damp(current, target, VISEME_DAMP_SPEED, delta)
      }
    }
  })

  return <primitive ref={group} object={scene} scale={2} position={[0, -1.5, 0]} />
}

export default function Assistant3D({ avatarState = 'idle' }) {
  const isSpeaking = avatarState === 'speaking'

  return (
    <div className="absolute inset-0 z-0">
      <Canvas camera={{ position: [0, 1, 5], fov: 50 }}>
        <ambientLight intensity={0.5} />
        <directionalLight position={[10, 10, 5]} intensity={1.2} />

        <Environment preset="city" />

        <Suspense fallback={null}>
          <SelaModel isSpeaking={isSpeaking} />
          <ContactShadows position={[0, -1.5, 0]} opacity={0.5} scale={10} blur={2} far={4} />
        </Suspense>

        {/* Memungkinkan karakter diputar 360 derajat (drag horizontal bebas penuh).
            Sudut vertikal (polar) dibatasi supaya kamera tidak menembus lantai/langit-langit. */}
        <OrbitControls
          makeDefault
          target={[0, 0.3, 0]}
          enablePan={false}
          minDistance={2.5}
          maxDistance={8}
          minPolarAngle={Math.PI / 6}
          maxPolarAngle={Math.PI - Math.PI / 6}
        />
      </Canvas>
    </div>
  )
}

useGLTF.preload('/models/SELA_BARU.glb')
