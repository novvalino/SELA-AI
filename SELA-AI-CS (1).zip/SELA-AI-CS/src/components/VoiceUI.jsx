import { useState, useRef, useEffect } from "react";
import LiveCaption from "./LiveCaption";
import {
  transcribeAudio,
  getChatCompletion,
  speakText,
  getTimeBasedGreeting,
  archiveConversationSession,
  prepareTranscriptForRag,
  looksLikeShortValidQuery,
} from "../lib/ai";
import { t } from "../lib/translations";

const SILENCE_DURATION = 850;
const MIN_SPEECH_MS = 500;
const MIN_BLOB_SIZE = 30000;
const MAX_RECORD_MS = 20000;
const THRESHOLD_MULTIPLIER = 2.8;
const BASELINE_SAMPLE_MS = 500;
const EARLY_SPEECH_THRESHOLD_MULTIPLIER = 1.6;
const MIN_TRANSCRIPT_CHARS = 6;
const QUICK_COMMIT_SILENCE_MS = 550;
const QUICK_COMMIT_MIN_SPEECH_MS = 500;
const MIN_RMS_FOR_VALID_SPEECH = 10;
const IDLE_SESSION_MS = 90 * 1000;
const FACE_LOST_END_MS = 12 * 1000;

const FAREWELL_KEYWORDS = [
  "terima kasih", "terimakasih", "makasih", "sampai jumpa", 
  "sampai bertemu", "selamat tinggal", "dadah", "bye", 
  "thanks", "thank you",
];
const isFarewell = (text) => FAREWELL_KEYWORDS.some((kw) => text.toLowerCase().includes(kw));

export default function VoiceUI({
  currentChat,
  onSend,
  onReceive,
  onNewChat,
  onReset,
  lang = "id",
  setLang,
  theme = "light",
  onAvatarStateChange,
}) {
  const [avatarState, setAvatarState] = useState("idle");

  // Laporkan setiap perubahan avatarState ("idle" | "listening" | "thinking" | "speaking")
  // ke komponen induk (App.jsx), supaya Assistant3D bisa tahu kapan harus
  // memainkan animasi "Talking" / gerakan tangan.
  useEffect(() => {
    onAvatarStateChange?.(avatarState);
  }, [avatarState, onAvatarStateChange]);
  const [micDenied, setMicDenied] = useState(false);
  const [activated, setActivated] = useState(false);
  const [faceDetected, setFaceDetected] = useState(false);
  const [langSelected, setLangSelected] = useState(false);
  const [awaitingLangSelect, setAwaitingLangSelect] = useState(false);

  // Refs 
  const isListeningRef = useRef(false);
  const isProcessingRef = useRef(false);
  const streamRef = useRef(null);
  const audioCtxRef = useRef(null);
  const analyserRef = useRef(null);
  const recorderRef = useRef(null);
  const aiRequestSeqRef = useRef(0);
  const vadFrameRef = useRef(null);
  const silenceStartRef = useRef(null);
  const hasSpeechRef = useRef(false);
  const speechStartRef = useRef(null);
  const firstSpeechDetectedAtRef = useRef(null);
  const baselineStartedAtRef = useRef(null);
  const dynamicThresholdRef = useRef(10);
  const suppressRecorderOnStopRef = useRef(false);
  const lastInteractionTimeRef = useRef(Date.now());
  const sessionEndingRef = useRef(false);
  const currentChatRef = useRef(currentChat);
  const langRef = useRef(lang);

  // Face detection refs
  const audioUnlockedRef = useRef(false);
  const activatedRef = useRef(false);
  const videoRef = useRef(null);
  const videoStreamRef = useRef(null);
  const faceDetectorRef = useRef(null);
  const faceFrameRef = useRef(null);
  const lastFaceTimeRef = useRef(0);
  const lastDetectRef = useRef(0);
  const properFaceTimeRef = useRef(null);
  const PROPER_FACE_CONFIRMATION_MS = 1000;
  const MIN_FACE_SIZE_RATIO = 0.2;

  useEffect(() => { activatedRef.current = activated; }, [activated]);
  useEffect(() => { currentChatRef.current = currentChat; }, [currentChat]);
  useEffect(() => { langRef.current = lang; }, [lang]);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("kiosk") === "1") {
      audioUnlockedRef.current = true;
      console.log("[SELA] Kiosk mode aktif — audio auto-unlocked, menunggu wajah...");
    }
  }, []);

  useEffect(() => {
    if (!activated && videoRef.current && videoStreamRef.current) {
      videoRef.current.srcObject = videoStreamRef.current;
      videoRef.current.play().catch(() => {});
    }
  }, [activated]);

  const speakWithAvatar = (text, speechLang = lang, onDone = null) => {
    speakText(
      text,
      () => setAvatarState("speaking"),
      () => {
        setAvatarState("idle");
        if (onDone) onDone();
      },
      speechLang,
    );
  };

  const speakSequenceWithAvatar = (segments = [], onComplete = null) => {
    const queue = segments.filter((segment) => segment?.text);
    const playNext = (index) => {
      if (index >= queue.length) {
        if (onComplete) onComplete();
        return;
      }
      const segment = queue[index];
      speakWithAvatar(segment.text, segment.lang || lang, () => {
        playNext(index + 1);
      });
    };
    playNext(0);
  };

  const markSessionInteraction = () => {
    lastInteractionTimeRef.current = Date.now();
  };

  const endSessionRef = useRef(null);
  endSessionRef.current = (endReason = "session_end") => {
    if (sessionEndingRef.current) return;
    sessionEndingRef.current = true;
    suppressRecorderOnStopRef.current = true;

    stopListening();
    window.speechSynthesis?.cancel();

    const chatSnapshot = currentChatRef.current;
    if (chatSnapshot?.messages?.length) {
      archiveConversationSession({
        currentChat: chatSnapshot,
        lang: langRef.current,
        endedByFarewell: false,
        endReason,
      });
    }

    isProcessingRef.current = false;
    activatedRef.current = false;
    setActivated(false);
    setAvatarState("idle");
    setLangSelected(false);
    setAwaitingLangSelect(false);
    setFaceDetected(false);
    properFaceTimeRef.current = null;
    lastFaceTimeRef.current = 0;
    if (onReset) onReset();

    setTimeout(() => {
      sessionEndingRef.current = false;
      suppressRecorderOnStopRef.current = false;
      markSessionInteraction();
    }, 250);
  };

  const autoActivateRef = useRef(null);
  autoActivateRef.current = () => {
    if (activatedRef.current || isProcessingRef.current) return;
    activatedRef.current = true;
    isProcessingRef.current = true;
    markSessionInteraction();
    setActivated(true);
    setLangSelected(false);
    setAwaitingLangSelect(false);

    const greetID = "Halo! Selamat datang di UCIC. Saya SELA.";
    const askID = "Mau bicara dalam Bahasa Indonesia atau Bahasa Inggris?";
    const greetEN = "Hello! Welcome to UCIC. I'm SELA.";
    const askEN = "Would you like to speak in Indonesian or English?";

    speakSequenceWithAvatar(
      [
        { text: greetID, lang: "id" },
        { text: greetEN, lang: "en" },
        { text: askID, lang: "id" },
        { text: askEN, lang: "en" },
      ],
      () => {
        isProcessingRef.current = false;
        setAvatarState("idle");
        setAwaitingLangSelect(true);
      },
    );
  };

  useEffect(() => {
    let destroyed = false;
    const startCamera = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { width: { ideal: 640 }, height: { ideal: 480 } },
          audio: false,
        });
        if (destroyed) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        videoStreamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play().catch(() => {});
        }
      } catch (e) {
        setTimeout(() => startCamera(), 3000);
      }
    };

    const initDetector = async () => {
      try {
        const { FaceDetector, FilesetResolver } = await import("@mediapipe/tasks-vision");
        const vision = await FilesetResolver.forVisionTasks(
          "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.3/wasm"
        );
        if (destroyed) return;
        faceDetectorRef.current = await FaceDetector.createFromOptions(vision, {
          baseOptions: {
            modelAssetPath: "https://storage.googleapis.com/mediapipe-models/face_detector/blaze_face_short_range/float16/1/blaze_face_short_range.tflite",
            delegate: "GPU",
          },
          runningMode: "VIDEO",
          minDetectionConfidence: 0.5,
        });
        startDetectionLoop();
      } catch (e) {
        console.warn("[SELA Cam] Face detector gagal load:", e.message);
      }
    };

    const startDetectionLoop = () => {
      const loop = () => {
        faceFrameRef.current = requestAnimationFrame(loop);
        if (!faceDetectorRef.current || !videoRef.current || videoRef.current.readyState < 2) return;

        const now = Date.now();
        if (now - lastDetectRef.current < 500) return;
        lastDetectRef.current = now;

        try {
          const result = faceDetectorRef.current.detectForVideo(videoRef.current, now);
          const hasFace = result.detections.length > 0;
          const vidW = videoRef.current.videoWidth || 640;

          const facingCamera = result.detections.some((det) => {
            const kps = det.keypoints;
            const box = det.boundingBox;
            if (!kps || kps.length < 3 || !box) return false;
            const eye0 = kps[0], eye1 = kps[1], nose = kps[2];
            const eyeDist = Math.abs(eye0.x - eye1.x); 
            const boxWidthNorm = box.width / vidW; 

            if (boxWidthNorm < MIN_FACE_SIZE_RATIO) return false;
            if (boxWidthNorm > 0 && eyeDist / boxWidthNorm < 0.3) return false;

            const midEyeX = (eye0.x + eye1.x) / 2;
            if (eyeDist > 0 && Math.abs(nose.x - midEyeX) / eyeDist > 0.25) return false;

            const eyeHeightDiff = Math.abs(eye0.y - eye1.y);
            if (eyeHeightDiff > eyeDist * 0.2) return false; 

            return true;
          });

          if (hasFace && facingCamera) {
            lastFaceTimeRef.current = now;
            if (properFaceTimeRef.current === null) {
              properFaceTimeRef.current = now;
              setFaceDetected(true);
            } else {
              const confirmedDuration = now - properFaceTimeRef.current;
              if (
                confirmedDuration >= PROPER_FACE_CONFIRMATION_MS &&
                audioUnlockedRef.current &&
                !activatedRef.current &&
                !isProcessingRef.current &&
                !sessionEndingRef.current
              ) {
                properFaceTimeRef.current = null;
                autoActivateRef.current();
              }
            }
          } else {
            properFaceTimeRef.current = null; 
            if (
              activatedRef.current &&
              !sessionEndingRef.current &&
              lastFaceTimeRef.current > 0 &&
              !hasFace &&
              now - lastFaceTimeRef.current > FACE_LOST_END_MS
            ) {
              endSessionRef.current?.("face_lost");
            } else if (!hasFace && now - lastFaceTimeRef.current > 3000) {
              setFaceDetected((prev) => prev ? false : prev);
            } else if (hasFace && !facingCamera) {
              lastFaceTimeRef.current = 0;
              setFaceDetected((prev) => prev ? false : prev);
            }
          }
        } catch (_) {}
      };
      faceFrameRef.current = requestAnimationFrame(loop);
    };

    startCamera();
    initDetector();

    return () => {
      destroyed = true;
      cancelAnimationFrame(faceFrameRef.current);
      videoStreamRef.current?.getTracks().forEach((t) => t.stop());
      videoStreamRef.current = null;
    };
  }, []);

  const stopListening = () => {
    isListeningRef.current = false;
    cancelAnimationFrame(vadFrameRef.current);
    if (recorderRef.current?.state !== "inactive") recorderRef.current?.stop();
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    audioCtxRef.current?.close().catch(() => {});
    audioCtxRef.current = null;
    analyserRef.current = null;
    silenceStartRef.current = null;
    hasSpeechRef.current = false;
    speechStartRef.current = null;
    firstSpeechDetectedAtRef.current = null;
    baselineStartedAtRef.current = null;
  };

  const startListeningRef = useRef(null);
  startListeningRef.current = async () => {
    if (isListeningRef.current || isProcessingRef.current) return;
    // Jangan pernah mulai merekam selama SELA masih bicara/antre bicara —
    // ini mencegah mic "mendengar" suara SELA sendiri (tabrakan/echo).
    if (window.speechSynthesis?.speaking || window.speechSynthesis?.pending) {
      setTimeout(() => startListeningRef.current?.(), 300);
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: { ideal: true },
          noiseSuppression: { ideal: true },
          autoGainControl: { ideal: true },
          channelCount: { ideal: 1 },
          sampleRate: { ideal: 16000 },
          sampleSize: { ideal: 16 },
          latency: { ideal: 0.01 },
        },
      });
      streamRef.current = stream;
      setMicDenied(false);
      isListeningRef.current = true;

      const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      audioCtxRef.current = audioCtx;
      const source = audioCtx.createMediaStreamSource(stream);
      const analyser = audioCtx.createAnalyser();
      analyser.fftSize = 1024;
      source.connect(analyser);
      analyserRef.current = analyser;

      const recorder = new MediaRecorder(stream);
      recorderRef.current = recorder;
      let chunks = [];

      recorder.ondataavailable = (e) => { if (e.data.size > 0) chunks.push(e.data); };

      recorder.onstop = () => {
        if (suppressRecorderOnStopRef.current) {
          chunks = [];
          stopListening();
          suppressRecorderOnStopRef.current = false;
          return;
        }
        const speechDuration = speechStartRef.current ? Date.now() - speechStartRef.current : 0;
        const audioBlob = new Blob(chunks, { type: "audio/webm" });
        const hadSpeech = hasSpeechRef.current;
        
        stopListening();

        if (!hadSpeech || speechDuration < MIN_SPEECH_MS || audioBlob.size < MIN_BLOB_SIZE) {
          setAvatarState("idle");
          // Tidak auto-listen lagi — pengguna menekan tombol "Tekan untuk
          // Bicara" lagi kalau mau mengulang.
          return;
        }

        processAudioRef.current(audioBlob);
      };

      recorder.start(100);
      setAvatarState("listening");
      baselineStartedAtRef.current = Date.now();

      const maxTimer = setTimeout(() => {
        if (recorderRef.current?.state !== "inactive") recorderRef.current.stop();
      }, MAX_RECORD_MS);

      const data = new Uint8Array(analyser.fftSize);
      let baselineRmsValues = [];

      const baselineCheck = () => {
        if (!isListeningRef.current) return;
        analyser.getByteTimeDomainData(data);
        const rms = Math.sqrt(data.reduce((s, v) => s + (v - 128) * (v - 128), 0) / data.length);
        baselineRmsValues.push(rms);
        const avgSoFar = baselineRmsValues.reduce((a, b) => a + b, 0) / baselineRmsValues.length;
        const provisionalThreshold = Math.max(MIN_RMS_FOR_VALID_SPEECH, avgSoFar * EARLY_SPEECH_THRESHOLD_MULTIPLIER);

        if (rms > provisionalThreshold && !hasSpeechRef.current) {
          hasSpeechRef.current = true;
          speechStartRef.current = Date.now();
          firstSpeechDetectedAtRef.current = speechStartRef.current;
          dynamicThresholdRef.current = Math.max(MIN_RMS_FOR_VALID_SPEECH, avgSoFar * THRESHOLD_MULTIPLIER);
          startActualVAD();
          return;
        }

        if (Date.now() - baselineStartedAtRef.current < BASELINE_SAMPLE_MS) {
          vadFrameRef.current = requestAnimationFrame(baselineCheck);
        } else {
          const avgBaseline = baselineRmsValues.reduce((a, b) => a + b, 0) / baselineRmsValues.length;
          dynamicThresholdRef.current = Math.max(MIN_RMS_FOR_VALID_SPEECH, avgBaseline * THRESHOLD_MULTIPLIER);
          startActualVAD();
        }
      };

      vadFrameRef.current = requestAnimationFrame(baselineCheck);

      const startActualVAD = () => {
        const checkSilence = () => {
          if (!isListeningRef.current) {
            clearTimeout(maxTimer);
            return;
          }
          analyser.getByteTimeDomainData(data);
          const rms = Math.sqrt(data.reduce((s, v) => s + (v - 128) * (v - 128), 0) / data.length);

          if (rms > dynamicThresholdRef.current) {
            if (!hasSpeechRef.current) {
              hasSpeechRef.current = true;
              speechStartRef.current = Date.now();
              firstSpeechDetectedAtRef.current = speechStartRef.current;
            }
            silenceStartRef.current = null;
          } else if (hasSpeechRef.current) {
            if (!silenceStartRef.current) {
              silenceStartRef.current = Date.now();
            } else if (
              Date.now() - silenceStartRef.current >
              (speechStartRef.current && Date.now() - speechStartRef.current >= QUICK_COMMIT_MIN_SPEECH_MS
                ? QUICK_COMMIT_SILENCE_MS : SILENCE_DURATION)
            ) {
              clearTimeout(maxTimer);
              if (recorderRef.current?.state !== "inactive") {
                recorderRef.current.stop();
              }
              return;
            }
          }
          vadFrameRef.current = requestAnimationFrame(checkSilence);
        };
        vadFrameRef.current = requestAnimationFrame(checkSilence);
      };
    } catch (err) {
      setMicDenied(true);
      setAvatarState("idle");
      isListeningRef.current = false;
    }
  };

  const processAudioRef = useRef(null);
  processAudioRef.current = async (audioBlob) => {
    isProcessingRef.current = true;
    setAvatarState("thinking");
    try {
      const rawText = await transcribeAudio(audioBlob, lang);

      if (!rawText || rawText.trim().length === 0) {
        isProcessingRef.current = false;
        setAvatarState("idle");
        // Tidak auto-listen lagi — pengguna menekan tombol untuk mencoba lagi.
        return;
      }

      const preparedTranscript = prepareTranscriptForRag(rawText);
      const text = preparedTranscript.cleanedText;

      const words = text?.trim().split(/\s+/) || [];
      const isNoise = !text?.trim() || text.trim().length < MIN_TRANSCRIPT_CHARS || (words.length <= 2 && text.length < 18 && !looksLikeShortValidQuery(text));

      if (isNoise) {
        isProcessingRef.current = false;
        setAvatarState("idle");
        return;
      }

      markSessionInteraction();
      if (isFarewell(text)) {
        handleFarewell(text);
        return;
      }

      onSend(text);
      const requestId = ++aiRequestSeqRef.current;

      const history = (currentChat?.messages || []).map((m) => ({
        role: m.role,
        content: m.text,
      }));
      history.push({ role: "user", content: text });
      const response = await getChatCompletion(history, lang);
      if (requestId !== aiRequestSeqRef.current) return;

      if (response.text?.includes("[IGNORE_NOISE]")) {
        isProcessingRef.current = false;
        setAvatarState("idle");
        return;
      }

      if (onReceive) onReceive(response);
      markSessionInteraction();

      const spokenText = response.spokenText || response.text;
      // Estimasi durasi bicara dibuat lebih longgar supaya fallback ini
      // tidak memotong SELA di tengah kalimat (penyebab lain dari "tabrakan").
      const estDuration = Math.max(4000, spokenText.length * 110);
      const ttsFallback = setTimeout(() => {
        if (isProcessingRef.current) {
          window.speechSynthesis?.cancel();
          setAvatarState("idle");
          isProcessingRef.current = false;
        }
      }, estDuration + 3000);

      speakText(
        spokenText,
        () => setAvatarState("speaking"),
        () => {
          clearTimeout(ttsFallback);
          setAvatarState("idle");
          isProcessingRef.current = false;
          // Mic tidak otomatis menyala lagi — menunggu pengguna menekan tombol
          // "Tekan untuk Bicara" untuk giliran bicara berikutnya.
        },
        response.detectedLang || lang,
      );
    } catch (error) {
      if (onReceive) onReceive(t[lang].error_stt);
      setAvatarState("idle");
      isProcessingRef.current = false;
    }
  };

  // Mic TIDAK lagi otomatis menyala setelah aktivasi — supaya tidak terlalu
  // sensitif menangkap suara/keramaian sekitar, pengguna harus menekan tombol
  // "Tekan untuk Bicara" sendiri setiap kali ingin berbicara dengan Sela.
  useEffect(() => {
    if (!activated) {
      stopListening();
      window.speechSynthesis?.cancel();
      setAvatarState("idle");
      isProcessingRef.current = false;
      return;
    }
    return () => {
      stopListening();
      window.speechSynthesis?.cancel();
      isProcessingRef.current = false;
    };
  }, [activated]);

  useEffect(() => {
    const timer = setInterval(() => {
      if (!activatedRef.current || sessionEndingRef.current) return;
      if (isListeningRef.current || isProcessingRef.current) return;
      if (Date.now() - lastInteractionTimeRef.current > IDLE_SESSION_MS) {
        endSessionRef.current?.("idle_timeout");
      }
    }, 3000);
    return () => clearInterval(timer);
  }, []);

  const handleFarewell = (userText) => {
    aiRequestSeqRef.current++;
    markSessionInteraction();
    onSend(userText);
    stopListening();
    window.speechSynthesis?.cancel();
    isProcessingRef.current = true;

    const farewellChat = currentChat
      ? { ...currentChat, messages: [...(currentChat.messages || []), { role: "user", text: userText, ts: new Date() }] }
      : null;

    const msg = lang === "id" ? "Sama-sama! Senang bisa membantu. Selamat datang kembali kapan saja ya!" : "You're welcome! Happy to help. Feel free to come back anytime!";

    if (onReceive) onReceive(msg);

    const farewellFallback = setTimeout(() => {
      archiveConversationSession({ currentChat: farewellChat, lang, endedByFarewell: true, endReason: "farewell" });
      isProcessingRef.current = false;
      activatedRef.current = false;
      setAvatarState("idle");
      setActivated(false);
      if (onReset) onReset();
    }, 6000);

    speakWithAvatar(
      msg,
      lang,
      () => {
        clearTimeout(farewellFallback);
        archiveConversationSession({ currentChat: farewellChat, lang, endedByFarewell: true, endReason: "farewell" });
        isProcessingRef.current = false;
        activatedRef.current = false;
        setAvatarState("idle");
        setActivated(false);
        setLangSelected(false);
        setAwaitingLangSelect(false);
        if (onReset) onReset();
      },
    );
  };

  const handleLangSelect = (chosen) => {
    markSessionInteraction();
    if (setLang) setLang(chosen);
    setLangSelected(true);
    setAwaitingLangSelect(false);
    window.speechSynthesis?.cancel();
    isProcessingRef.current = false;

    const timeBasedGreeting = getTimeBasedGreeting(chosen);
    speakWithAvatar(timeBasedGreeting, chosen, () => {
      // Menunggu pengguna menekan tombol "Tekan untuk Bicara" (tidak auto-listen).
    });
  };

  const statusLabel = () => {
    if (micDenied) return lang === "id" ? "Izin mikrofon ditolak" : "Microphone permission denied";
    switch (avatarState) {
      case "listening": return t[lang].listening;
      case "thinking": return lang === "id" ? "Sedang berpikir..." : "Thinking...";
      case "speaking": return lang === "id" ? "SELA sedang bicara..." : "SELA is speaking...";
      default: return lang === "id" ? "Tekan tombol untuk bicara" : "Press the button to talk";
    }
  };

  const messages = currentChat?.messages ?? [];
  const latestMsg = messages[messages.length - 1];

  return (
    <div className="w-full h-full flex flex-col items-center justify-end pb-8">
      {/* Hidden Camera untuk mendeteksi Face Tracking */}
      <div className="absolute opacity-0 pointer-events-none overflow-hidden w-1 h-1">
        <video ref={videoRef} muted playsInline autoPlay />
      </div>

      {activated ? (
        <div className="flex flex-col items-center gap-4 relative z-20 pointer-events-auto w-full max-w-md px-4">
          
          {/* Overlay Transparan Live Captions */}
          {avatarState === "speaking" && latestMsg?.role === "assistant" && (
            <div className="w-full">
              <LiveCaption
                text={latestMsg.text}
                isLoading={false}
                avatarState={avatarState}
              />
            </div>
          )}

          {/* Status Label (Transparan dan melayang) — satu-satunya indikator status,
              termasuk untuk kondisi "sedang berpikir", supaya tidak dobel dengan
              status lain di atasnya. */}
          <p className="text-xs text-gray-700 dark:text-gray-300 font-bold uppercase tracking-tighter text-center bg-white/50 dark:bg-slate-900/50 px-4 py-1.5 rounded-full backdrop-blur-sm drop-shadow-sm border border-white/20">
            {statusLabel()}
          </p>

          {micDenied && (
            <button
              onClick={() => {
                setMicDenied(false);
                startListeningRef.current?.();
              }}
              className="text-xs text-blue-600 underline bg-white/90 px-3 py-1.5 rounded-full shadow-sm mt-2"
            >
              {lang === "id" ? "Coba lagi" : "Retry"}
            </button>
          )}

          {/* Tombol Pemilihan Bahasa */}
          {awaitingLangSelect && !langSelected && avatarState === "idle" && (
            <div className="flex gap-3 animate-fade-in mt-2">
              <button
                onClick={() => handleLangSelect("id")}
                className="px-6 py-2.5 rounded-full text-sm font-semibold bg-blue-500 hover:bg-blue-600 active:scale-95 text-white shadow-lg transition-all duration-150"
              >
                🇮🇩 Indonesia
              </button>
              <button
                onClick={() => handleLangSelect("en")}
                className="px-6 py-2.5 rounded-full text-sm font-semibold bg-white hover:bg-gray-50 active:scale-95 text-gray-700 border border-gray-200 shadow-lg dark:bg-slate-700 dark:text-gray-100 dark:border-slate-600 transition-all duration-150"
              >
                🇬🇧 English
              </button>
            </div>
          )}

          {/* Tombol "Tekan untuk Bicara" — mic HANYA aktif kalau tombol ini
              ditekan, supaya tidak terlalu sensitif menangkap suara/keramaian
              di sekitar Sela. */}
          {langSelected && !awaitingLangSelect && !micDenied && (
            <button
              onClick={() => startListeningRef.current?.()}
              disabled={avatarState !== "idle"}
              className={`mt-2 flex items-center gap-2 px-6 py-3 rounded-full text-sm font-semibold shadow-lg transition-all duration-150
                ${avatarState === "listening"
                  ? "bg-red-500 text-white animate-pulse"
                  : avatarState === "idle"
                  ? "bg-blue-500 hover:bg-blue-600 active:scale-95 text-white"
                  : "bg-gray-300 text-gray-500 cursor-not-allowed"}`}
            >
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 1a4 4 0 0 1 4 4v6a4 4 0 0 1-8 0V5a4 4 0 0 1 4-4zm6 10a6 6 0 0 1-12 0H4a8 8 0 0 0 16 0h-2zm-6 8v3h-2v-3a8.03 8.03 0 0 1-5.65-2.35l1.41-1.41A6 6 0 0 0 12 19a6 6 0 0 0 4.24-1.76l1.41 1.41A8.03 8.03 0 0 1 12 21z" />
              </svg>
              {avatarState === "listening"
                ? (lang === "id" ? "Sedang mendengarkan..." : "Listening...")
                : (lang === "id" ? "Tekan untuk Bicara" : "Press to Talk")}
            </button>
          )}
        </div>
      ) : (
        <div className="flex flex-col items-center gap-4 relative z-20 pointer-events-auto">
          {/* Instruksi saat sebelum aktivasi / mendeteksi wajah */}
          <div className="animate-pulse bg-blue-500/10 border border-blue-200/50 rounded-full px-6 py-3 backdrop-blur-md">
            <p className="text-sm font-medium text-blue-700 dark:text-blue-300 text-center">
              {lang === 'id' ? 'Menunggu wajah terdeteksi...' : 'Waiting for face detection...'}
            </p>
          </div>
        </div>
      )}
    </div>
  );
}