import { useState, useRef, useEffect } from 'react'
import QRCode from 'qrcode'
import Navbar from './components/Navbar'
import VoiceUI from './components/VoiceUI'
import HamburgerMenu from './components/HamburgerMenu'
import Settings from './components/Settings'
import Help from './components/Help'
import Assistant3D from './components/Assistant3D'
import { getChatCompletion, speakText, transcribeAudio } from './lib/ai'

function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2)
}

const URL_PATTERN = /(https?:\/\/[^\s]+)/g
const TRAILING_PUNCTUATION = /[.,!?;:)\]]$/
const BOLD_PATTERN = /(\*\*[^*]+\*\*)/g

// Pecah sepotong teks biasa (non-URL) berdasarkan tanda **...** menjadi
// campuran string biasa dan elemen <strong> supaya teks inti tampil tebal.
function renderBoldSegments(text = '', keyPrefix = 'seg') {
  return text
    .split(BOLD_PATTERN)
    .filter(Boolean)
    .map((segment, i) => {
      const boldMatch = segment.match(/^\*\*(.*)\*\*$/)
      if (boldMatch) {
        return (
          <strong key={`${keyPrefix}-b-${i}`} className="font-semibold">
            {boldMatch[1]}
          </strong>
        )
      }
      return segment
    })
}

// Kartu QR yang ditaruh di atas teks link (mis. link PMB) di dalam popup chat.
function QrAboveLink({ url }) {
  const [qrSrc, setQrSrc] = useState('')

  useEffect(() => {
    let active = true

    QRCode.toDataURL(url, {
      width: 120,
      margin: 1,
      color: {
        dark: '#111827',
        light: '#ffffff'
      }
    }).then(src => {
      if (active) setQrSrc(src)
    }).catch(() => {
      if (active) setQrSrc('')
    })

    return () => {
      active = false
    }
  }, [url])

  return (
    <span className="my-2 flex w-fit flex-col items-start gap-1.5">
      {qrSrc ? (
        <img
          src={qrSrc}
          alt="QR code untuk link"
          className="h-24 w-24 rounded-md border border-gray-200 bg-white p-1 shadow-sm"
          loading="lazy"
        />
      ) : (
        <span className="flex h-24 w-24 items-center justify-center rounded-md bg-gray-100 text-[10px] font-medium text-gray-400">
          QR
        </span>
      )}
      <a
        href={url}
        target="_blank"
        rel="noopener noreferrer"
        className="break-all text-blue-600 underline dark:text-blue-400"
      >
        {url}
      </a>
    </span>
  )
}

// Pecah teks balasan Sela: setiap link (mis. link pendaftaran PMB) diganti
// dengan kartu QR di atasnya, teks lain tetap tampil apa adanya.
function renderMessageWithQr(text = '') {
  const parts = []
  let lastIndex = 0
  let segIndex = 0

  for (const match of text.matchAll(URL_PATTERN)) {
    const rawUrl = match[0]
    const start = match.index
    let url = rawUrl
    let trailing = ''

    while (TRAILING_PUNCTUATION.test(url)) {
      trailing = url.slice(-1) + trailing
      url = url.slice(0, -1)
    }

    if (start > lastIndex) {
      parts.push(...renderBoldSegments(text.slice(lastIndex, start), `seg-${segIndex++}`))
    }

    if (url) {
      parts.push(<QrAboveLink key={`qr-${start}`} url={url} />)
    }

    if (trailing) {
      parts.push(...renderBoldSegments(trailing, `seg-${segIndex++}`))
    }

    lastIndex = start + rawUrl.length
  }

  if (lastIndex < text.length) {
    parts.push(...renderBoldSegments(text.slice(lastIndex), `seg-${segIndex++}`))
  }

  return parts
}

function createChat(title = 'New Chat') {
  return { id: generateId(), title, messages: [], createdAt: new Date() }
}

const TypewriterText = ({ text = '' }) => {
  const [displayedText, setDisplayedText] = useState('')

  useEffect(() => {
    if (!text) {
      setDisplayedText('')
      return undefined
    }

    setDisplayedText('')
    let i = 0
    const timer = setInterval(() => {
      i++
      // Selalu ambil potongan langsung dari `text` asli (bukan menumpuk dari
      // state sebelumnya) supaya tidak rawan karakter hilang/dobel jika efek
      // ini sempat berjalan lebih dari sekali (mis. React StrictMode).
      setDisplayedText(text.slice(0, i))
      if (i >= text.length) clearInterval(timer)
    }, 30)

    return () => clearInterval(timer)
  }, [text])

  return <span>{renderMessageWithQr(displayedText)}</span>
}

export default function App() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [page, setPage] = useState('home')
  const [chats, setChats] = useState([])
  const [currentChatId, setCurrentChatId] = useState(null)
  const [scrolled, setScrolled] = useState(false)
  const [lang, setLang] = useState('id')
  const [theme, setTheme] = useState('light')

  const [isChatOpen, setIsChatOpen] = useState(false)
  const [isFaqOpen, setIsFaqOpen] = useState(false)
  const [isChatLoading, setIsChatLoading] = useState(false)
  const [latestSelaId, setLatestSelaId] = useState(null)

  // Suara SELA di widget "Chat dengan Sela" (default aktif; bisa dimatikan
  // lewat tombol speaker di header widget)
  const [isSoundOn, setIsSoundOn] = useState(true)
  const lastSpokenIdRef = useRef(null)

  // Ingat pesan SELA mana yang animasi ketiknya SUDAH pernah ditampilkan.
  // Ref ini hidup di level App (tidak ikut ter-reset saat widget chat
  // ditutup/dibuka lagi), jadi menutup lalu membuka ulang widget tidak
  // akan memicu animasi ketik ulang untuk pesan yang sudah pernah tampil.
  const typedSelaIdRef = useRef(null)

  // Status avatar 3D ("idle" | "listening" | "thinking" | "speaking"),
  // dilaporkan oleh VoiceUI supaya Assistant3D tahu kapan harus memutar
  // animasi bicara dan menggerakkan tangan.
  const [avatarState, setAvatarState] = useState('idle')
  
  // State baru untuk mengontrol input chat
  const [chatInputValue, setChatInputValue] = useState('')

  // State & Ref untuk tombol bicara (rekam suara → teks) di widget chat
  const [isRecording, setIsRecording] = useState(false)
  const [isTranscribing, setIsTranscribing] = useState(false)
  const [micError, setMicError] = useState('')
  const mediaRecorderRef = useRef(null)
  const audioChunksRef = useRef([])
  const micStreamRef = useRef(null)

  // State & Ref untuk Scroll
  const [showScrollTop, setShowScrollTop] = useState(false)
  const chatEndRef = useRef(null)
  const chatTopRef = useRef(null) 

  useEffect(() => {
    const currentChat = chats.find(c => c.id === currentChatId)
    const msgs = currentChat?.messages ?? []
    const last = msgs[msgs.length - 1]
    if (last && last.role === 'assistant') {
      setLatestSelaId(last.id)
    }
  }, [chats, currentChatId])

  // Tandai id ini "sudah pernah diketik" segera setelah jadi pesan terbaru —
  // dilakukan di sini (bukan menunggu animasi TypewriterText selesai) supaya
  // tetap aman walau widget sempat ditutup di tengah animasi berjalan.
  useEffect(() => {
    if (latestSelaId) typedSelaIdRef.current = latestSelaId
  }, [latestSelaId])

  // Setiap kali widget dibuka (termasuk dibuka ulang berkali-kali), samakan
  // penanda "pesan terakhir yang sudah diucapkan" dengan pesan terakhir yang
  // ada SEKARANG. Ini mencegah dua hal: (1) riwayat lama ikut dibacakan
  // ulang, dan (2) efek di bawah memanggil speakText() lagi untuk balasan
  // yang kebetulan sedang diucapkan oleh avatar utama saat widget ini
  // dibuka — speakText() selalu memutus ucapan yang sedang berjalan sebelum
  // memulai yang baru, jadi tanpa ini avatar bisa terdengar "kepotong" tiap
  // widget dibuka. Sebelumnya ini hanya jalan sekali (saat lastSpokenIdRef
  // masih null), jadi bug ini muncul lagi di pembukaan widget berikutnya.
  useEffect(() => {
    if (!isChatOpen) return
    const currentChat = chats.find(c => c.id === currentChatId)
    const msgs = currentChat?.messages ?? []
    const last = msgs[msgs.length - 1]
    if (last && last.role === 'assistant') {
      lastSpokenIdRef.current = last.id
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isChatOpen])

  // Ucapkan balasan SELA yang baru muncul di widget chat teks.
  // Hanya bicara untuk pesan yang benar-benar baru (bukan riwayat lama saat
  // widget dibuka ulang), dan berhenti otomatis jika suara dimatikan atau
  // widget ditutup.
  useEffect(() => {
    if (!isChatOpen || !isSoundOn) return
    const currentChat = chats.find(c => c.id === currentChatId)
    const msgs = currentChat?.messages ?? []
    const last = msgs[msgs.length - 1]
    if (!last || last.role !== 'assistant') return
    if (lastSpokenIdRef.current === last.id) return

    lastSpokenIdRef.current = last.id
    setAvatarState('speaking')
    speakText(
      last.spokenText || last.text,
      () => setAvatarState('speaking'),
      () => setAvatarState('idle'),
      last.speechLang || lang,
    )
  }, [chats, currentChatId, isChatOpen, isSoundOn, lang])

  // Hentikan suara HANYA saat tombol suara (🔇) dimatikan secara eksplisit.
  // Membuka/menutup widget chat TIDAK boleh memutus ucapan SELA yang sedang
  // berjalan (baik dari widget ini maupun dari avatar utama) — kalimat yang
  // sedang diucapkan harus tetap selesai walau widget dibuka/ditutup di
  // tengah jalan.
  useEffect(() => {
    if (!isSoundOn) {
      window.speechSynthesis?.cancel()
    }
  }, [isSoundOn])

  // Hentikan suara saat komponen unmount
  useEffect(() => {
    return () => window.speechSynthesis?.cancel()
  }, [])

  useEffect(() => {
    if (isChatOpen) {
      chatEndRef.current?.scrollIntoView({ behavior: 'smooth' })
    }
  }, [chats, isChatOpen])

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark')
    } else {
      document.documentElement.classList.remove('dark')
    }
  }, [theme])

  const currentChatIdRef = useRef(currentChatId)
  useEffect(() => {
    currentChatIdRef.current = currentChatId
  }, [currentChatId])

  const navigate = (target) => {
    setMenuOpen(false)
    setPage(target)
  }

  const goHome = () => setPage('home')

  const handleNewChat = () => {
    const chat = createChat('New Chat')
    setChats(prev => [chat, ...prev])
    setCurrentChatId(chat.id)
    setMenuOpen(false)
    setPage('home')
  }

  const handleSelectChat = (id) => {
    setCurrentChatId(id)
    setMenuOpen(false)
    setPage('home')
  }

  const handleResetChat = () => {
    setChats([])
    setCurrentChatId(null)
    currentChatIdRef.current = null
  }

  const handleDeleteChat = (id) => {
    setChats(prev => prev.filter(c => c.id !== id))
    if (currentChatId === id) {
      const remaining = chats.filter(c => c.id !== id)
      setCurrentChatId(remaining.length > 0 ? remaining[0].id : null)
    }
  }

  const handleSendMessage = (text) => {
    if (!text.trim()) return
    const msgId = generateId()
    let targetId = currentChatIdRef.current;

    if (!targetId) {
      const newChat = createChat(text.slice(0, 40));
      newChat.messages = [{ id: msgId, role: 'user', text, ts: new Date() }];
      setChats(prev => [newChat, ...prev]);
      setCurrentChatId(newChat.id);
      currentChatIdRef.current = newChat.id; 
      return;
    }

    setChats(prev => prev.map(c => {
      if (c.id !== targetId) return c
      const updatedTitle = c.messages.length === 0 ? text.slice(0, 40) : c.title
      return {
        ...c,
        title: updatedTitle,
        messages: [...c.messages, { id: msgId, role: 'user', text, ts: new Date() }]
      }
    }))
  }

  // Kirim teks (baik dari ketikan maupun hasil transkrip suara) ke Sela,
  // dipakai bersama oleh form submit dan tombol bicara supaya alurnya sama.
  const sendChatMessage = async (text) => {
    if (!text.trim() || isChatLoading) return
    handleSendMessage(text)
    setChatInputValue('')
    setIsChatLoading(true)

    const history = currentChat?.messages?.map(m => ({
      role: m.role,
      content: m.text
    })) || []

    history.push({ role: 'user', content: text })

    try {
      const response = await getChatCompletion(history, lang)
      const replyText = typeof response === 'string' ? response : response?.text || ''

      if (replyText.includes('GNORE_NOISE') || replyText.includes('IGNORE_NOISE')) {
        handleReceiveMessage(
          lang === 'id'
            ? 'Halo! Sela di sini. Ada yang ingin ditanyakan seputar kampus?'
            : 'Hello! Sela here. Do you have any questions about the campus?'
        )
      } else {
        handleReceiveMessage(response)
      }
    } catch (error) {
      console.error('Chat API Error:', error)
      handleReceiveMessage(lang === 'id' ? 'Maaf, terjadi kesalahan saat menghubungi server.' : 'Sorry, a network error occurred.')
    } finally {
      setIsChatLoading(false)
    }
  }

  // Mulai merekam suara pengguna lewat mikrofon browser.
  const startRecording = async () => {
    setMicError('')
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      micStreamRef.current = stream
      audioChunksRef.current = []

      const recorder = new MediaRecorder(stream)
      mediaRecorderRef.current = recorder

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) audioChunksRef.current.push(e.data)
      }

      recorder.onstop = async () => {
        micStreamRef.current?.getTracks().forEach(track => track.stop())
        micStreamRef.current = null

        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' })
        audioChunksRef.current = []

        if (audioBlob.size < 1000) {
          setIsTranscribing(false)
          return
        }

        setIsTranscribing(true)
        try {
          const text = await transcribeAudio(audioBlob, lang)
          if (text?.trim()) {
            await sendChatMessage(text.trim())
          }
        } catch (error) {
          console.error('Transcribe error:', error)
          setMicError(lang === 'id' ? 'Gagal mengenali suara. Coba lagi ya!' : 'Could not recognize speech. Please try again!')
        } finally {
          setIsTranscribing(false)
        }
      }

      recorder.start()
      setIsRecording(true)
    } catch (error) {
      console.error('Mic access error:', error)
      setMicError(lang === 'id' ? 'Izin mikrofon ditolak.' : 'Microphone permission denied.')
      setIsRecording(false)
    }
  }

  // Hentikan rekaman; transkrip & pengiriman pesan dilanjutkan di onstop.
  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop()
    }
    setIsRecording(false)
  }

  const toggleRecording = () => {
    if (isRecording) {
      stopRecording()
    } else {
      startRecording()
    }
  }

  // Hentikan rekaman jika komponen unmount saat mikrofon masih aktif
  useEffect(() => {
    return () => {
      micStreamRef.current?.getTracks().forEach(track => track.stop())
    }
  }, [])

  const handleReceiveMessage = (data) => {
    const targetId = currentChatIdRef.current;
    const text = typeof data === 'string' ? data : data?.text
    const suggestions = typeof data === 'object' ? data?.suggestions : undefined
    const media = typeof data === 'object' ? data?.media : undefined
    const spokenText = typeof data === 'object' ? data?.spokenText : undefined
    const speechLang = typeof data === 'object' ? data?.detectedLang : undefined

    if (!text?.trim() || !targetId) return

    const msgId = generateId()
    setChats(prev => prev.map(c => {
      if (c.id !== targetId) return c
      const msgObj = { id: msgId, role: 'assistant', text: text.trim(), ts: new Date() }
      if (suggestions && suggestions.length > 0) {
        msgObj.suggestions = suggestions
      }
      if (media && media.length > 0) {
        msgObj.media = media
      }
      if (spokenText) {
        msgObj.spokenText = spokenText
      }
      if (speechLang) {
        msgObj.speechLang = speechLang
      }
      return {
        ...c,
        messages: [...c.messages, msgObj]
      }
    }))
  }

  const handleBubbleScroll = (e) => {
    if (e.target.scrollTop > 150) {
      setShowScrollTop(true)
    } else {
      setShowScrollTop(false)
    }
  }

  const scrollToBubbleTop = () => {
    chatTopRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  // Fungsi baru untuk menangani klik pada suggestion How To Ask
  const handleSuggestionClick = (suggestion) => {
    const cleanText = suggestion.replace(/^"|"$/g, ""); // Hapus tanda kutip awal & akhir
    setChatInputValue(cleanText); // Isi ke dalam kotak chat
    setIsChatOpen(true); // Pastikan kotak chat terbuka
    setIsFaqOpen(false); // Tutup popup How To Ask
  }

  const currentChat = chats.find(c => c.id === currentChatId) || null

  const faqSuggestions = [
    '"Berapa biaya UKT jurusan Teknik Informatika?"',
    '"Tolong jelaskan alur pendaftaran mahasiswa baru."',
    '"Apa saja fasilitas yang ada di kampus?"'
  ];

  return (
    <div className="fixed inset-0 flex flex-col overflow-hidden">
      <div className="pointer-events-none absolute inset-0 -z-10 overflow-hidden bg-[#f8faff] dark:bg-slate-950 transition-colors duration-500">
        <div className="absolute -top-[10%] -left-[10%] w-[50%] h-[50%] rounded-full bg-blue-200/40 dark:bg-blue-900/20 blur-[120px] animate-float-1" />
        <div className="absolute top-[20%] -right-[10%] w-[45%] h-[45%] rounded-full bg-indigo-200/30 dark:bg-indigo-900/15 blur-[120px] animate-float-2" />
        <div className="absolute -bottom-[10%] left-[20%] w-[40%] h-[40%] rounded-full bg-sky-100/50 dark:bg-blue-800/20 blur-[120px] animate-float-3" />
      </div>

      {page === 'home' ? (
        <>
          <Navbar
            onMenuClick={() => setMenuOpen(true)}
            lang={lang}
            setLang={setLang}
            theme={theme}
            setTheme={setTheme}
          />
          
          <div className="flex-1 relative w-full h-full">
            <Assistant3D avatarState={avatarState} />
            
            <div className="absolute inset-0 z-10 pointer-events-none flex flex-col justify-end pb-24">
              <div className="pointer-events-auto w-full">
                <VoiceUI
                  currentChat={currentChat}
                  onSend={handleSendMessage}
                  onReceive={handleReceiveMessage}
                  onNewChat={handleNewChat}
                  onReset={handleResetChat}
                  lang={lang}
                  setLang={setLang}
                  theme={theme}
                  onAvatarStateChange={setAvatarState}
                />
              </div>
            </div>
          </div>

          <div className="absolute bottom-6 left-6 z-50 flex flex-col items-start">
            {isFaqOpen && (
              <div className="mb-4 w-72 bg-white dark:bg-slate-800 rounded-2xl shadow-xl border border-gray-100 dark:border-slate-700 p-4 transform transition-all duration-300">
                <div className="flex justify-between items-center mb-3">
                  <h3 className="font-semibold text-blue-600 dark:text-blue-400">💡 How to Ask Sela</h3>
                  <button onClick={() => setIsFaqOpen(false)} className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200">✖</button>
                </div>
                <ul className="text-sm text-gray-600 dark:text-gray-300 space-y-2">
                  {faqSuggestions.map((item, idx) => (
                    <li 
                      key={idx}
                      onClick={() => handleSuggestionClick(item)}
                      className="cursor-pointer hover:text-blue-600 dark:hover:text-blue-400 hover:bg-blue-50 dark:hover:bg-slate-700 p-2 -mx-2 rounded-md transition-colors"
                    >
                      • {item}
                    </li>
                  ))}
                </ul>
              </div>
            )}
            <button 
              onClick={() => setIsFaqOpen(!isFaqOpen)}
              className="px-4 py-2 bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 font-medium rounded-full shadow-lg border border-gray-100 dark:border-slate-700 hover:bg-gray-50 dark:hover:bg-slate-700 transition-all"
            >
              ❓ How to Ask
            </button>
          </div>

          <div className="absolute bottom-6 right-6 z-50 flex flex-col items-end">
            {isChatOpen && (
              <div className="mb-4 w-80 h-[28rem] bg-white dark:bg-slate-800 rounded-2xl shadow-xl border border-gray-100 dark:border-slate-700 flex flex-col overflow-hidden transform transition-all duration-300 relative">
                <div className="bg-blue-600 p-4 flex justify-between items-center text-white relative z-20">
                  <h3 className="font-semibold">Chat dengan Sela</h3>
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setIsSoundOn(prev => !prev)}
                      className="hover:text-gray-200"
                      title={isSoundOn ? 'Matikan suara SELA' : 'Nyalakan suara SELA'}
                    >
                      {isSoundOn ? '🔊' : '🔇'}
                    </button>
                    <button onClick={() => setIsChatOpen(false)} className="hover:text-gray-200">✖</button>
                  </div>
                </div>
                
                {showScrollTop && (
                  <button 
                    onClick={scrollToBubbleTop}
                    className="absolute top-16 right-4 w-8 h-8 bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 border border-gray-200 dark:border-slate-600 rounded-full shadow-lg flex items-center justify-center z-30 hover:bg-gray-50 dark:hover:bg-slate-600 transition-all opacity-90 hover:opacity-100"
                    title="Scroll ke atas"
                  >
                    ↑
                  </button>
                )}

                <div 
                  className="flex-1 p-4 overflow-y-auto bg-gray-50 dark:bg-slate-900/50 flex flex-col gap-2 relative scroll-smooth"
                  onScroll={handleBubbleScroll}
                >
                  <div ref={chatTopRef} /> 

                  {currentChat && currentChat.messages && currentChat.messages.length > 0 ? (
                    currentChat.messages.map((msg, idx) => (
                      <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-[80%] px-3 py-2 rounded-2xl text-sm ${msg.role === 'user' ? 'bg-blue-600 text-white rounded-br-none' : 'bg-white dark:bg-slate-700 text-gray-800 dark:text-gray-100 rounded-bl-none shadow-sm border border-gray-100 dark:border-slate-600 whitespace-pre-wrap'}`}>
                          {msg.role === 'assistant' && msg.id === latestSelaId && typedSelaIdRef.current !== msg.id ? (
                            <TypewriterText text={msg.text} />
                          ) : msg.role === 'assistant' ? (
                            renderMessageWithQr(msg.text)
                          ) : (
                            msg.text
                          )}
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-center text-xs text-gray-400 mt-4">Mulai percakapan teks di sini...</p>
                  )}

                  {isChatLoading && (
                    <div className="flex justify-start">
                      <div className="max-w-[80%] px-4 py-3 rounded-2xl bg-white dark:bg-slate-700 rounded-bl-none shadow-sm border border-gray-100 dark:border-slate-600 flex items-center gap-1.5">
                        <div className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                        <div className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                        <div className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                      </div>
                    </div>
                  )}
                  <div ref={chatEndRef} />
                </div>

                <form
                  onSubmit={async (e) => {
                    e.preventDefault();
                    const text = chatInputValue.trim();
                    if (text) await sendChatMessage(text);
                  }}
                  className="p-3 bg-white dark:bg-slate-800 border-t border-gray-100 dark:border-slate-700 relative flex flex-col gap-1.5 z-20"
                >
                  {micError && (
                    <p className="text-[11px] text-red-500 px-1">{micError}</p>
                  )}
                  <div className="relative flex items-center">
                    <input
                      name="chatInput"
                      type="text"
                      value={chatInputValue} // Terhubung dengan state chatInputValue
                      onChange={(e) => setChatInputValue(e.target.value)} // Update state saat mengetik
                      disabled={isChatLoading || isRecording || isTranscribing}
                      placeholder={
                        isRecording
                          ? (lang === 'id' ? 'Sedang mendengarkan...' : 'Listening...')
                          : isTranscribing
                          ? (lang === 'id' ? 'Mengenali suara...' : 'Transcribing...')
                          : isChatLoading
                          ? 'Sela mengetik...'
                          : 'Ketik pertanyaanmu...'
                      }
                      className="w-full bg-gray-100 dark:bg-slate-700 text-gray-800 dark:text-white rounded-full pl-4 pr-20 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-60"
                      autoComplete="off"
                    />

                    {/* Tombol Bicara (rekam suara → teks) */}
                    <button
                      type="button"
                      onClick={toggleRecording}
                      disabled={isChatLoading || isTranscribing}
                      title={
                        isRecording
                          ? (lang === 'id' ? 'Berhenti merekam' : 'Stop recording')
                          : (lang === 'id' ? 'Bicara ke Sela' : 'Speak to Sela')
                      }
                      aria-label={lang === 'id' ? 'Bicara ke Sela' : 'Speak to Sela'}
                      className={`absolute right-12 w-8 h-8 rounded-full flex items-center justify-center transition-all text-xs disabled:opacity-60
                        ${isRecording
                          ? 'bg-red-500 text-white animate-pulse hover:bg-red-600'
                          : 'bg-gray-200 dark:bg-slate-600 text-gray-600 dark:text-gray-200 hover:bg-gray-300 dark:hover:bg-slate-500'}`}
                    >
                      {isTranscribing ? (
                        <svg className="w-3.5 h-3.5 animate-spin" viewBox="0 0 24 24" fill="none">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
                        </svg>
                      ) : (
                        <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M12 1a4 4 0 0 1 4 4v6a4 4 0 0 1-8 0V5a4 4 0 0 1 4-4zm6 10a6 6 0 0 1-12 0H4a8 8 0 0 0 16 0h-2zm-6 8v3h-2v-3a8.03 8.03 0 0 1-5.65-2.35l1.41-1.41A6 6 0 0 0 12 19a6 6 0 0 0 4.24-1.76l1.41 1.41A8.03 8.03 0 0 1 12 21z" />
                        </svg>
                      )}
                    </button>

                    <button
                      type="submit"
                      disabled={isChatLoading || isRecording || isTranscribing || !chatInputValue.trim()}
                      className="absolute right-2 w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center hover:bg-blue-700 transition-all text-xs disabled:opacity-60 disabled:hover:bg-blue-600"
                    >
                      ➤
                    </button>
                  </div>
                </form>
              </div>
            )}
            <button 
              onClick={() => setIsChatOpen(!isChatOpen)}
              className="w-14 h-14 bg-blue-600 text-white rounded-full shadow-lg flex items-center justify-center hover:bg-blue-700 transition-all text-2xl"
            >
              💬
            </button>
          </div>
        </>
      ) : (
        <div className="flex-1 overflow-y-auto" onScroll={(e) => setScrolled(e.target.scrollTop > 10)}>
          {page === 'settings' && <Settings onBack={goHome} scrolled={scrolled} lang={lang} setLang={setLang} theme={theme} setTheme={setTheme} />}
          {page === 'help'     && <Help     onBack={goHome} scrolled={scrolled} lang={lang} theme={theme} />}
        </div>
      )}

      <HamburgerMenu
        isOpen={menuOpen}
        onClose={() => setMenuOpen(false)}
        chats={chats}
        currentChatId={currentChatId}
        onNewChat={handleNewChat}
        onSelectChat={handleSelectChat}
        onDeleteChat={handleDeleteChat}
        onOpenSettings={() => navigate('settings')}
        onOpenHelp={() => navigate('help')}
        lang={lang}
        theme={theme}
      />
    </div>
  )
}